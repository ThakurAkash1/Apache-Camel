package com.camel;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelApplication {

    public static void main(String[] args) throws Exception {

        try (// Create a new instance of the DefaultCamelContext
             CamelContext context = new DefaultCamelContext()) {
            // Add a new route to the context
            context.addRoutes(new RouteBuilder() {

                @Override
                public void configure() throws Exception {

                    // Define the route ID
                    from("file://C:\\Camel-Work-Tasks\\FileFolders\\source?delete=true").routeId("fileRoute")
                            .setBody(simple("${body}Hi")) // Append "Hi" to the body of each file
                            .log("Processing file ${header.CamelFileName}") // Log the processing of each file
                            .to("file://C:\\Camel-Work-Tasks\\FileFolders\\backup") // Backup directory

                            // Route files based on their content
                            .choice()
                                    .when(body().contains("Mumbai")) // If file contains "Mumbai" in its body
                                    .log("Routing file ${header.CamelFileName} to Mumbai directory") // Log routing to Mumbai
                                    .to("file://C:\\Camel-Work-Tasks\\FileFolders\\Mumbai\\Mumbai?fileName=${file:name.noext}-${date:now:yyyyMMdd-HHmmssSSS}.${file:ext}")

									.when(body().contains("Bangalore")) // If file contains "Bangalore" in its body
									.log("Routing file ${header.CamelFileName} to Bangalore directory") // Log routing to Bangalore directory
									.to("file://C:\\Camel-Work-Tasks\\FileFolders\\Bangalore\\Bangalore?fileName=${file:name.noext}-${date:now:yyyyMMdd-HHmmssSSS}.${file:ext}") 	

                                .otherwise() // If file doesn't contain any of the specified keywords
                                    .log("Routing file ${header.CamelFileName} to output directory")
                                    .to("file://C:\\Camel-Work-Tasks\\FileFolders\\backup");
                }
            });

            // Start the context
            context.start();

            // Keep the context running
            while (true) {
                Thread.sleep(1000); // Sleep to avoid busy-waiting
            }
        }
    }
}



































































// package com.camel;

// import org.apache.camel.CamelContext;
// import org.apache.camel.builder.RouteBuilder;
// import org.apache.camel.impl.DefaultCamelContext;

// public class CamelApplication {

// 	public static void main(String[] args) throws Exception {

// 		try (// Create a new instance of the DefaultCamelContext
// 		CamelContext context = new DefaultCamelContext()) {
// 			// Add a new route to the context
// 			context.addRoutes(new RouteBuilder() {

// 				@Override
// 				public void configure() throws Exception {

// 					from("file://C:/source?delete=true")
// 							.setBody(simple("${body}Hi")) // Append "Hi" to the body of each file
// 							.log("Processing file ${header.CamelFileName}") // Log the processing of each file
// 							.to("file://C://backup") // Backup directory

// 							// Route files based on their content
// 							.choice()
// 							.when(body().contains("Mumbai")) // If file contains "Mumbai" in its body
// 							.log("Routing file ${header.CamelFileName} to Bangalore directory") // Log routing to Mumbai
			
// 							.to("file://C:/output/Mumbai?fileName=${file:name.noext}-${date:now:yyyyMMdd-HHmmssSSS}.${file:ext}")

// 							.otherwise() // If file doesn't contain any of the specified keywords
// 							.log("Routing file ${header.CamelFileName} to output directory")
// 							.to("file://C:/backup");

// 				}
// 			});

// 			// starts the context
// 			while (true)
// 				context.start();
// 		}
// 	}

// }
