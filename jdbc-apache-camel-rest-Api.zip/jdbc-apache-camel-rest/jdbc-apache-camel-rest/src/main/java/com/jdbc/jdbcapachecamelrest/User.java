package com.jdbc.jdbcapachecamelrest;
import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;

import org.springframework.data.annotation.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;

@Entity
@AllArgsConstructor
@Data
@NoArgsConstructor
public class User {

    @Id
    private int id;
    private String name;
    private String email;
   @JsonFormat(pattern = "yyyy-MM-dd")
    private Date dob;

    public int calculateAge(Date dob) {
        // TODO Auto-generated method stub
        LocalDate birthDate = dob.toLocalDate();
        LocalDate currentDate = LocalDate.now();
        return Period.between(birthDate, currentDate).getYears();
}
}
