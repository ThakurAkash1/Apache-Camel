package com.jdbc.jdbcapachecamelrest;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class JdbcRoute extends RouteBuilder {

    @Autowired
    private DataSource dataSource;

    

    @Override
    public void configure() {
        restConfiguration().component("jetty")
                .port(9090).host("localhost")
                .bindingMode(RestBindingMode.json);

                from("rest:get:user").routeId("get-user")
                .setBody(simple("SELECT * FROM user"))
                .to("jdbc:myDataSource")
                .log("${body}")
                .marshal().json().process(exchange -> {
                    ObjectMapper objectMapper = new ObjectMapper();
                    String body = exchange.getIn().getBody(String.class);
                    List<Map<String, Object>> list = objectMapper.readValue(body, new TypeReference<List<Map<String, Object>>>() {});
                    List<Map<String, Object>> formattedList = new ArrayList<>();
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    for (Map<String, Object> map : list) {
                        long timestamp = (long) map.get("dob");
                        Date dob = new Date(timestamp);
                        map.put("Date_of_Birth", sdf.format(dob));
                        User user =new User();
                        int age = user.calculateAge(dob);
                        map.put("Age", age);
                        map.remove("dob");
                        formattedList.add(map);
                    }
                    exchange.getIn().setBody(objectMapper.writeValueAsString(formattedList));
                }).process(exchange -> {
                                            String body = exchange.getIn().getBody(String.class);
                    body = body.replaceAll("\"dob\"", "\"Date_of_Birth\"");
                    exchange.getIn().setBody( body);
                });
                

        from("rest:post:addUser").routeId("post-user")
                        .unmarshal().json()
                        .process(exchange -> {
                        Map<String, Object> bodyMap = exchange.getIn().getBody(Map.class);
                        int id = (int) bodyMap.get("id");
                        String name = (String) bodyMap.get("name");
                        String email = (String) bodyMap.get("email");
                        String dobStr = (String) bodyMap.get("dob");
                        Date dob = Date.valueOf(dobStr);
                        String query = "INSERT INTO user (id, name, email, dob) VALUES (" + id + ", '" + name + "', '" + email + "', '" + dob + "')";
                        exchange.getIn().setBody(query);
                        })
                        .to("jdbc:myDataSource")
                        .log("${body}")
                        .marshal().json().process(exchange -> {
                        exchange.getIn().setBody("{\"success\": true, \"message\": \"User has created\"}");
                        });

        from("rest:put:updateUser/{id}").routeId("put-user")
                        .unmarshal().json()
                        .process(exchange -> {
                        Map<String, Object> bodyMap = exchange.getIn().getBody(Map.class);
                        int id = Integer.parseInt((String) exchange.getIn().getHeader("id"));
                        String name = (String) bodyMap.get("name");
                        String email = (String) bodyMap.get("email");
                        String dobStr = (String) bodyMap.get("dob");
                        Date dob = Date.valueOf(dobStr);
                        String query = "UPDATE user SET name = '" + name + "', email = '" + email + "', dob = '" + dob + "' WHERE id = " + id;
                        exchange.getIn().setBody(query);
                        })
                        .to("jdbc:myDataSource")
                        .log("${body}")
                        .marshal().json().process(exchange -> {
                        exchange.getIn().setBody("{\"success\": true, \"message\": \"User has updated\"}");
                        });


        from("rest:delete:deleteUser/{id}").routeId("delete-user")
                        .process(exchange -> {
                        int id = Integer.parseInt((String) exchange.getIn().getHeader("id"));
                        String query = "DELETE FROM user WHERE id = " + id;
                        exchange.getIn().setBody(query);
                        })
                        .to("jdbc:myDataSource")
                        .log("${body}")
                        .marshal().json().process(exchange -> {
                        exchange.getIn().setBody("{\"success\": true, \"message\": \"User has deleted\"}");
                        });
    }


}
