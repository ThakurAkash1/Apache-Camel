package com.jdbc.jdbcapachecamelrest;

import javax.sql.DataSource;

import org.apache.camel.CamelContext;

import org.apache.camel.impl.DefaultCamelContext;

import org.apache.camel.support.DefaultRegistry;
import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class JdbcApacheCamelRestApplication {

	public static void main(String[] args) throws Exception  {
        SpringApplication.run(JdbcApacheCamelRestApplication.class, args);
    }

	@Bean
    @ConfigurationProperties(prefix = "spring.datasource")
    public DataSource dataSource() {
        return new BasicDataSource();
    }

    @Bean
    public CamelContext camelContext(DataSource dataSource) throws Exception {
        DefaultRegistry reg = new DefaultRegistry();
        reg.bind("myDataSource", dataSource);
        CamelContext context = new DefaultCamelContext(reg);
        context.addRoutes(new JdbcRoute());
        context.start();
        return context;
    }
}

