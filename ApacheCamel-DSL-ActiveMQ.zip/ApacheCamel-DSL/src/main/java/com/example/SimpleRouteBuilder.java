package com.example;

import org.apache.camel.builder.RouteBuilder;

public class SimpleRouteBuilder extends RouteBuilder {
    // Configure route for both source to ActiveMQ and ActiveMQ to destination
    @Override
    public void configure() throws Exception {
        // Route from source directory to ActiveMQ queue
        from("file:C:\\Camel-Work-Tasks\\FileFolders\\source").routeId("SourceToActiveMQ")
            .log("Sending file ${header.CamelFileName} to ActiveMQ")
            .to("jms:queue:testQueue");

        // Route from ActiveMQ queue to destination directory
        from("jms:queue:testQueue").routeId("ActiveMQToDestination")
            .log("Received file ${header.CamelFileName} from ActiveMQ")
            .setBody(constant("Thank You")) // Replace the entire content with "Thank You"
            .to("file:C:\\Camel-Work-Tasks\\FileFolders\\destination");
    }
}





// import org.apache.camel.builder.RouteBuilder;

// public class SimpleRouteBuilder extends RouteBuilder {
// 	//configure route for jms component
//     @Override
//     public void configure() throws Exception {
//         from("file:C:\\Camel-Work-Tasks\\FileFolders\\source").split().tokenize("\n").to("jms:queue:javainuse");
//     }

// }
