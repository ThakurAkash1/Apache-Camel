package com.api;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.stereotype.Component;

@Component
public class MyCamelRoute extends RouteBuilder {

    @Override
    public void configure() throws Exception {
        // Listen for HTTP requests on port 9090 with context path /api
        from("netty-http:http://0.0.0.0:9090/api")
            .routeId("NettyHttpRoute")
            .log("Received message: ${body}")
            .doTry()
                // Unmarshal JSON request payload to Java object
                .unmarshal().json(JsonLibrary.Jackson) 
                 // Log unmarshalled Java object
                .log("Unmarshalled JSON: ${body}")
                // Marshal Java response object to JSON
                .marshal().json(JsonLibrary.Jackson) 
                 // Log marshalled JSON response
                .log("Marshalled JSON: ${body}")
            .doCatch(Exception.class)
                .log("Error processing message: ${exception.message}")
                .setBody(constant("An error occurred while processing the request."));
    }
}


















// import org.apache.camel.builder.RouteBuilder;
// import org.springframework.stereotype.Component;

// @Component
// public class MyCamelRoute extends RouteBuilder {

//     @Override
//     public void configure() throws Exception {
//         // Listen for HTTP requests on port 9090 with context path /api
//         from("netty-http:http://0.0.0.0:9090/api")
//             .routeId("NettyHttpRoute") 
//             .log("Received message: ${body}")
//             .transform().constant("Message received from Netty-Http is successfull!");
//     }
// }