package com.parentpom.camelparentpom;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class SimpleRoute extends RouteBuilder {

    @Override
    public void configure() throws Exception {
        
        //Pring Statement
        System.out.println("Hello Welcome");
    }
    
}