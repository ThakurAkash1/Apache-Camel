package com.parentpom.camelparentpom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamelparentpomApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamelparentpomApplication.class, args);
	}

}
