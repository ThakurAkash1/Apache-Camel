package com.example.xmlfile.FileComponentRoute;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileComponentRouteApplicationTests {

	@Test
	void contextLoads() {
	}

}
